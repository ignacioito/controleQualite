package ca.qc.grasset._420_pa4_ag.lab02;

import org.junit.Assert;
import org.junit.Test;

public class TrieurTableauVideTest {

	public TrieurTableauVideTest() {

		super();

	}

	@Test
	public void test() {

		final int[] tableau = new int[] {};

		Trieur trieur = new Trieur();

		int[] tableauTrie = trieur.trier(tableau);

		Assert.assertArrayEquals(tableau, tableauTrie);
		Assert.assertEquals(0, tableauTrie.length);

	}

}
