package ca.qc.grasset._420_pa4_ag.lab02;

import org.junit.Assert;
import org.junit.Test;

public class TrieurTableauTrieTest {
	
	public TrieurTableauTrieTest() {
		
		super();
		
	}

	@Test
	public void test() {

		final int[] tableau = new int[] {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		
		Trieur trieur = new Trieur();
		
		int[] tableauTrie = trieur.trier(tableau);
		
		Assert.assertArrayEquals(tableau, tableauTrie);
		Assert.assertEquals(tableau.length, tableauTrie.length);
		
	}

}
