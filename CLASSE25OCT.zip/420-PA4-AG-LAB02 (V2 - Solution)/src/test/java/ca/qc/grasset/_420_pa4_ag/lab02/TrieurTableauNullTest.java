package ca.qc.grasset._420_pa4_ag.lab02;


import org.junit.Test;

public class TrieurTableauNullTest {
	
	public TrieurTableauNullTest() {
		
		super();
		
	} 

	@Test
	public void test() {
		
		Trieur trieur = new Trieur();
		trieur.trier(null);
		
	}

}
